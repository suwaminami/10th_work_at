<?php
//XSS対応（ echoする場所で使用！）
function h($str)
{
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

//DB接続関数：db_conn() 
//※関数を作成し、内容をreturnさせる。
//※ DBname等、今回の授業に合わせる。


//※ コメントアウトで変えるようにする。
function db_conn()
{
    try {
        $db_name = 'kidsmama_gs_db3';
        $db_id   = 'kidsmama';
        $db_pw   = 'minami22044329';
        $db_host = 'mysql1025.db.sakura.ne.jp';
        $pdo = new PDO('mysql:dbname=kidsmama_gs_db3;charset=utf8;host='mysql1025.db.sakura.ne.jp','kidsmama','minami22044329');
    } catch (PDOException $e) {
        exit('DB Connection Error:' . $e->getMessage());
    }
}


//SQLエラー関数：sql_error($stmt)
function sql_error($stmt)
{
    $error = $stmt->errorInfo();
    exit('SQLError:' . print_r($error, true));
}

//リダイレクト関数: redirect($file_name)
function redirect($file_name)
{
    header('Location: ' . $file_name );
    exit();
}
