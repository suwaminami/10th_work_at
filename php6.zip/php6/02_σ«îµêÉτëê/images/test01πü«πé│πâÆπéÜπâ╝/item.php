
<?php
  /*cookieを取得*/
  if(array_key_exists('fav_item', $_COOKIE)){
    $checked_items = $_COOKIE['fav_item'];
    $checked_items = json_decode($checked_items);
  }
?>
 
<div class="p-main" id="list">
 
  <div class="p-list">
 
  <?php if($checked_items):?>
    <div class="p-list__title">
      お気に入り登録しているページIはこちら
    </div>
    <div class="p-list_wrapper">
    <?php foreach ($checked_items as $checked_item) : ?>
      <div class="p-list__item">
		  <a href="<?php echo $permalink = get_permalink( $checked_item ); //パーマリンク ?>">
			  <div class="p-list__img">
				  <?php echo get_the_post_thumbnail( $checked_item ); //アイキャッチ画像 ?>
			  </div>
			  <div class="p-list__txt">
				  <p class="p-list__date dfont"><?php echo get_the_date( '',$checked_item ); //投稿日時 ?></p>
				  <p class="p-list__title"><?php echo $title = get_the_title($checked_item); //タイトル ?></p>
			  </div>
		  </a>
      </div>
    <?php endforeach;?>
  <?php else :?>
 
    <div class="p-not_fav_items">
      お気に入りに登録されているページはありません。
    </div>
 
  <?php endif;?>
    </div>
  </div>