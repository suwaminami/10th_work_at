<!doctype html>

<html lang="ja">
	<head>
		<meta charset="utf-8">
		<title>自動的に特定のページへジャンプさせる方法</title>
		<meta http-equiv="refresh" content="5;URL=http://kidsmama.sakura.ne.jp/app/sagasu.php">
	</head>
	<body>

		<p>位置情報を取得中。５秒後に自動ジャンプします。。。。</p>

		<p><a href="http://kidsmama.sakura.ne.jp/app/sagasu.php">自動的にジャンプしない場合は、こちらをクリックしてください。</a></p>



	</body>
</html>